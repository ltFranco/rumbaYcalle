import Hero from './components/Hero';
import Introduccion from './components/Introduccion';
import MisionVision from './components/MisionVision';
import Lineup from './components/Lineup';
import Servicios from './components/Servicios';
import Mercado from './components/Mercado';
import Oportunidades from './components/Oportunidades';
import Conceptos from './components/Conceptos';
import TechRider from './components/TechRider';
import Impacto from './components/Impacto';
import Fechas from './components/Fechas';
import Footer from './components/Footer';

function App() {
  return (
    <div className="min-h-screen bg-black">
      <Hero />
      <Introduccion />
      <MisionVision />
      <Lineup />
      <Servicios />
      <Mercado />
      <Oportunidades />
      <Conceptos />
      <TechRider />
      <Impacto />
      <Fechas />
      <Footer />
    </div>
  );
}

export default App;
