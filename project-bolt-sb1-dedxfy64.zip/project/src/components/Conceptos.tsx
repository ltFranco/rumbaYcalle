function Conceptos() {
  return (
    <section className="py-32 px-4 bg-black">
      <div className="max-w-7xl mx-auto">
        <h2 className="text-5xl md:text-6xl font-black text-white text-center mb-20">
          Cuatro conceptos clave sobre<br />Rumba & Calle Fest y su<br />innovación
        </h2>

        <div className="grid md:grid-cols-2 gap-8">
          <div className="bg-white rounded-3xl p-12">
            <p className="text-2xl text-gray-900 leading-relaxed">
              Rumba & Calle Fest ofrece <span className="font-bold">mini-festivales únicos</span> que conectan a
              los artistas con su audiencia.
            </p>
          </div>

          <div className="bg-white rounded-3xl p-12">
            <p className="text-2xl text-gray-900 leading-relaxed">
              La empresa se destaca por su <span className="font-bold">accesibilidad</span>, permitiendo que
              todos disfruten del arte.
            </p>
          </div>

          <div className="bg-white rounded-3xl p-12">
            <p className="text-2xl text-gray-900 leading-relaxed">
              Se compromete con el <span className="font-bold">apoyo al
              talento local</span>, fomentando nuevas
              oportunidades en la industria.
            </p>
          </div>

          <div className="bg-white rounded-3xl p-12">
            <p className="text-2xl text-gray-900 leading-relaxed">
              Con un enfoque en la <span className="font-bold">escalabilidad</span>, Rumba & Calle Fest
              tiene el potencial de crecer en el
              mercado.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}

export default Conceptos;
