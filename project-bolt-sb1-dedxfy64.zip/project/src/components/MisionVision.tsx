function MisionVision() {
  return (
    <section
      className="py-32 px-4 bg-cover bg-center relative"
      style={{
        backgroundImage: `url('https://images.pexels.com/photos/1190298/pexels-photo-1190298.jpeg?auto=compress&cs=tinysrgb&w=1920')`,
      }}
    >
      <div className="absolute inset-0 bg-black/70" />

      <div className="relative z-10 max-w-7xl mx-auto grid md:grid-cols-2 gap-16">
        <div>
          <h2 className="text-5xl md:text-6xl font-black text-white mb-8">
            MISION
          </h2>
          <p className="text-lg md:text-xl text-gray-200 leading-relaxed">
            Nuestra misión brindar entretenimiento de alta calidad
            y promover la cultura local e internacional, acercando la
            música a las comunidades más alejadas y fortaleciendo
            el sentido de pertenencia y alegría en cada pueblo.
          </p>
        </div>

        <div>
          <h2 className="text-5xl md:text-6xl font-black text-white mb-8">
            VISION
          </h2>
          <p className="text-lg md:text-xl text-gray-200 leading-relaxed">
            Nuestra vision convertirse en el festival de referencia
            en la República Dominicana, reconocido por su
            impacto social y su capacidad de unir a las personas
            a través de experiencias musicales inolvidables, en
            cada rincón del país.
          </p>
        </div>
      </div>
    </section>
  );
}

export default MisionVision;
