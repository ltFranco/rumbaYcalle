function Footer() {
  return (
    <footer
      className="py-32 px-4 relative"
      style={{
        backgroundImage: `url('https://images.pexels.com/photos/1105666/pexels-photo-1105666.jpeg?auto=compress&cs=tinysrgb&w=1920')`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
      }}
    >
      <div className="absolute inset-0 bg-gradient-to-t from-teal-900/90 via-blue-900/80 to-green-900/70" />

      <div className="relative z-10 max-w-7xl mx-auto grid md:grid-cols-2 gap-16 items-center">
        <div className="relative">
          <div className="aspect-[3/4] rounded-3xl overflow-hidden shadow-2xl">
            <img
              src="https://images.pexels.com/photos/1190298/pexels-photo-1190298.jpeg?auto=compress&cs=tinysrgb&w=800"
              alt="Rumba & Calle Fest"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
            <div className="absolute bottom-0 left-0 right-0 p-8">
              <h3 className="text-5xl font-black text-white mb-4">
                RUMBA<span className="text-white">&</span><br />CALLE
              </h3>
              <div className="inline-block bg-red-600 text-white text-3xl font-black px-6 py-2 -rotate-2 transform">
                FEST
              </div>
              <p className="text-sm text-gray-300 mt-6">
                LINE UP: JEZZY • LIL NAAY • LA PERVERSA • EL MAYOR CLASICO<br />
                PUYALO PANTERA • LA BABY • JOYZYZ
              </p>
            </div>
          </div>
        </div>

        <div className="text-center md:text-left">
          <h2 className="text-8xl md:text-9xl font-black text-white mb-8">
            THANK YOU!
          </h2>
          <p className="text-2xl text-gray-200 mb-8">
            Transformando las calles en escenarios vibrantes
          </p>
          <div className="flex flex-wrap gap-4 justify-center md:justify-start">
            <span className="text-gray-300 text-lg">Boletos en:</span>
            <span className="text-white font-bold text-lg">BOLETOS EXPRESS</span>
            <span className="text-white font-bold text-lg">7stage</span>
          </div>
        </div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto mt-16 pt-8 border-t border-white/20 text-center">
        <p className="text-gray-300">
          © 2024 Rumba & Calle Fest. Todos los derechos reservados.
        </p>
      </div>
    </footer>
  );
}

export default Footer;
