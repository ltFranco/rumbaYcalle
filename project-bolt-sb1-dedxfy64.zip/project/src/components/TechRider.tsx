import { Mic2, Lightbulb, Layers } from 'lucide-react';

function TechRider() {
  return (
    <section
      className="py-32 px-4 relative"
      style={{
        backgroundImage: `url('https://images.pexels.com/photos/2240771/pexels-photo-2240771.jpeg?auto=compress&cs=tinysrgb&w=1920')`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
      }}
    >
      <div className="absolute inset-0 bg-gradient-to-r from-red-900/90 to-black/80" />

      <div className="relative z-10 max-w-7xl mx-auto grid md:grid-cols-2 gap-16 items-center">
        <div className="relative">
          <div className="aspect-video rounded-2xl overflow-hidden shadow-2xl">
            <img
              src="https://images.pexels.com/photos/1481309/pexels-photo-1481309.jpeg?auto=compress&cs=tinysrgb&w=800"
              alt="Tech Setup"
              className="w-full h-full object-cover"
            />
          </div>
        </div>

        <div>
          <p className="text-xl md:text-2xl text-gray-200 leading-relaxed mb-12">
            En Rumba y Calle contamos con un equipo técnico
            y de producción altamente capacitado,
            comprometido con la excelencia en cada
            presentación. Nos enfocamos en cumplir con los
            más altos estándares de calidad para garantizar un
            show impactante, seguro y memorable. Nuestro
            rider técnico incluye:
          </p>

          <div className="space-y-6">
            <div className="flex items-start gap-4 bg-black/40 rounded-xl p-6 backdrop-blur-sm">
              <Mic2 className="w-8 h-8 text-red-500 flex-shrink-0 mt-1" />
              <p className="text-lg text-gray-200">
                Sonido de alta fidelidad y potencia profesional.
              </p>
            </div>

            <div className="flex items-start gap-4 bg-black/40 rounded-xl p-6 backdrop-blur-sm">
              <Lightbulb className="w-8 h-8 text-yellow-500 flex-shrink-0 mt-1" />
              <p className="text-lg text-gray-200">
                Iluminación creativa y dinámica que realza cada momento del espectáculo.
              </p>
            </div>

            <div className="flex items-start gap-4 bg-black/40 rounded-xl p-6 backdrop-blur-sm">
              <Layers className="w-8 h-8 text-teal-500 flex-shrink-0 mt-1" />
              <p className="text-lg text-gray-200">
                Escenario seguro, funcional y accesible para todos los artistas.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export default TechRider;
