function Oportunidades() {
  return (
    <section className="py-32 px-4 bg-black">
      <div className="max-w-7xl mx-auto">
        <h2 className="text-6xl md:text-7xl font-black text-white mb-8">
          Oportunidades en<br />Mini-Festivales
        </h2>
        <p className="text-2xl text-gray-300 mb-20">
          <span className="font-bold">La demanda local</span> crea un ambiente propicio para eventos.
        </p>

        <div className="grid md:grid-cols-3 gap-8">
          <div className="relative overflow-hidden rounded-2xl aspect-[4/5] group">
            <img
              src="https://images.pexels.com/photos/1763075/pexels-photo-1763075.jpeg?auto=compress&cs=tinysrgb&w=800"
              alt="Demanda Local"
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent" />
            <div className="absolute bottom-0 left-0 right-0 p-8">
              <h3 className="text-3xl font-black text-white mb-4">
                Demanda Local
              </h3>
              <p className="text-gray-200">
                La creciente <span className="font-bold">demanda de música en
                vivo</span> en la República Dominicana
                impulsa el interés por mini-festivales.
              </p>
            </div>
          </div>

          <div className="relative overflow-hidden rounded-2xl aspect-[4/5] group">
            <img
              src="https://images.pexels.com/photos/1105666/pexels-photo-1105666.jpeg?auto=compress&cs=tinysrgb&w=800"
              alt="Enfoque en Talento Nacional"
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent" />
            <div className="absolute bottom-0 left-0 right-0 p-8">
              <h3 className="text-3xl font-black text-white mb-4">
                Enfoque en Talento Nacional
              </h3>
              <p className="text-gray-200">
                Promover el <span className="font-bold">talento local</span> no solo
                apoya a los artistas, sino que
                también enriquece la cultura.
              </p>
            </div>
          </div>

          <div className="relative overflow-hidden rounded-2xl aspect-[4/5] group">
            <img
              src="https://images.pexels.com/photos/1267697/pexels-photo-1267697.jpeg?auto=compress&cs=tinysrgb&w=800"
              alt="Expansión de Oportunidades"
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent" />
            <div className="absolute bottom-0 left-0 right-0 p-8">
              <h3 className="text-3xl font-black text-white mb-4">
                Expansión de Oportunidades
              </h3>
              <p className="text-gray-200">
                Los mini-festivales ofrecen <span className="font-bold">nuevas
                oportunidades</span> para la comunidad,
                fomentando la cooperación y el
                desarrollo local.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export default Oportunidades;
