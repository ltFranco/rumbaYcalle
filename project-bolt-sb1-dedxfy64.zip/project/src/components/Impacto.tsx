function Impacto() {
  return (
    <section className="py-32 px-4 bg-black">
      <div className="max-w-4xl mx-auto text-center">
        <div className="mb-8">
          <span className="text-8xl md:text-9xl font-black text-white">+ 25,000</span>
        </div>
        <h2 className="text-6xl md:text-7xl font-black text-white">
          PERSONAS
        </h2>
      </div>
    </section>
  );
}

export default Impacto;
