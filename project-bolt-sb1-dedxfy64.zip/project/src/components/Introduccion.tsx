function Introduccion() {
  return (
    <section className="py-32 px-4 bg-black">
      <div className="max-w-5xl mx-auto text-center">
        <h2 className="text-6xl md:text-7xl font-black text-white mb-16">
          INTRODUCION
        </h2>
        <p className="text-xl md:text-2xl text-gray-300 leading-relaxed">
          Rumba y Calle es un festival de música y cultura que llega a 7 ciudades de la
          República Dominicana, con el objetivo de democratizar el acceso a eventos
          culturales y musicales. Este festival busca transformar las calles en
          escenarios vibrantes y ofrecer una experiencia única a las comunidades que,
          normalmente, no tienen la oportunidad de disfrutar de festivales en vivo.
        </p>
      </div>
    </section>
  );
}

export default Introduccion;
