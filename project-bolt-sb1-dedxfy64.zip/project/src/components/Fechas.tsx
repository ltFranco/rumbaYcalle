function Fechas() {
  const eventos = [
    { dia: '05', mes: 'DIC', ciudad: 'YAMASÁ', provincia: 'MONTE PLATA' },
    { dia: '06', mes: 'DIC', ciudad: 'SAN PEDRO', provincia: 'SAN PEDRO DE MACORÍS' },
    { dia: '12', mes: 'DIC', ciudad: 'HIGÜEY', provincia: 'LA ALTAGRACIA' },
    { dia: '13', mes: 'DIC', ciudad: 'VERÓN', provincia: 'PUNTA CANA' },
    { dia: '14', mes: 'DIC', ciudad: 'HATO MAYOR', provincia: 'HATO MAYOR DEL REY' },
    { dia: '19', mes: 'DIC', ciudad: 'HAINA', provincia: 'SAN CRISTÓBAL' },
    { dia: '30', mes: 'DIC', ciudad: 'LA VEGA', provincia: 'LA VEGA' },
  ];

  return (
    <section
      className="py-32 px-4 relative"
      style={{
        backgroundImage: `url('https://images.pexels.com/photos/1763075/pexels-photo-1763075.jpeg?auto=compress&cs=tinysrgb&w=1920')`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
      }}
    >
      <div className="absolute inset-0 bg-gradient-to-br from-orange-600/80 via-pink-600/70 to-teal-600/80" />

      <div className="relative z-10 max-w-7xl mx-auto">
        <div className="bg-gradient-to-r from-orange-600 to-teal-600 text-white text-5xl md:text-6xl font-black px-12 py-6 mb-16 inline-block rounded-r-full">
          FECHAS CONFIRMADAS
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {eventos.map((evento, index) => (
            <div
              key={index}
              className="bg-white/95 backdrop-blur-sm rounded-2xl p-8 hover:scale-105 transition-transform duration-300 shadow-xl"
            >
              <div className="flex items-center gap-6 mb-4">
                <div className="text-7xl font-black text-gray-900">
                  {evento.mes} {evento.dia}
                </div>
              </div>
              <h3 className="text-4xl font-black text-gray-900 mb-2">
                {evento.ciudad},
              </h3>
              <p className="text-xl text-gray-700 font-semibold">
                {evento.provincia}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

export default Fechas;
