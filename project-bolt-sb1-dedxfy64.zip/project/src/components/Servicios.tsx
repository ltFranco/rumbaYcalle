function Servicios() {
  return (
    <section className="py-32 px-4 bg-gradient-to-br from-gray-900 to-black">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-20">
          <h2 className="text-5xl md:text-6xl font-black text-white mb-8">
            Productos & Servicios de<br />Rumba & Calle Fest
          </h2>
          <p className="text-xl text-gray-300 max-w-4xl mx-auto">
            Descubre cómo Rumba & Calle Fest revoluciona la producción de eventos a
            través de conceptos innovadores y una producción integral para mini-festivales.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          <div className="bg-gray-800 rounded-2xl p-10 border border-gray-700 hover:border-orange-500 transition-all duration-300">
            <h3 className="text-3xl font-black text-white mb-6">
              Creación de Mini-Festivales
            </h3>
            <p className="text-gray-300 leading-relaxed">
              Nos especializamos en <span className="font-bold text-white">conceptos únicos</span> que
              capturan la esencia de la
              música local, ofreciendo
              experiencias memorables
              para los asistentes.
            </p>
          </div>

          <div className="bg-gray-800 rounded-2xl p-10 border border-gray-700 hover:border-teal-500 transition-all duration-300">
            <h3 className="text-3xl font-black text-white mb-6">
              Producción Integral
            </h3>
            <p className="text-gray-300 leading-relaxed">
              Gestionamos todos los
              aspectos de producción,
              desde la planificación
              hasta la ejecución,
              asegurando eventos <span className="font-bold text-white">profesionales y bien
              organizados</span>.
            </p>
          </div>

          <div className="bg-gray-800 rounded-2xl p-10 border border-gray-700 hover:border-red-500 transition-all duration-300">
            <h3 className="text-3xl font-black text-white mb-6">
              Marketing y Promoción
            </h3>
            <p className="text-gray-300 leading-relaxed">
              Implementamos
              estrategias efectivas de <span className="font-bold text-white">marketing</span>, utilizando
              plataformas digitales y
              redes sociales para
              maximizar la visibilidad y
              el alcance de cada
              evento.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}

export default Servicios;
