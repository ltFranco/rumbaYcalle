function Lineup() {
  const artists = [
    { name: 'JEY ONE', image: 'https://images.pexels.com/photos/1916824/pexels-photo-1916824.jpeg?auto=compress&cs=tinysrgb&w=400' },
    { name: 'LIL NAAY', image: 'https://images.pexels.com/photos/2479312/pexels-photo-2479312.jpeg?auto=compress&cs=tinysrgb&w=400' },
    { name: 'LA PERVERSA', image: 'https://images.pexels.com/photos/1587927/pexels-photo-1587927.jpeg?auto=compress&cs=tinysrgb&w=400' },
    { name: 'JEZZY', image: 'https://images.pexels.com/photos/1644888/pexels-photo-1644888.jpeg?auto=compress&cs=tinysrgb&w=600' },
    { name: 'MAYOR CLASICO', image: 'https://images.pexels.com/photos/1699161/pexels-photo-1699161.jpeg?auto=compress&cs=tinysrgb&w=400' },
    { name: 'LA BABY', image: 'https://images.pexels.com/photos/2100063/pexels-photo-2100063.jpeg?auto=compress&cs=tinysrgb&w=400' },
    { name: 'JOYZYZ', image: 'https://images.pexels.com/photos/1687931/pexels-photo-1687931.jpeg?auto=compress&cs=tinysrgb&w=400' },
    { name: 'PUYALO PANTERA', image: 'https://images.pexels.com/photos/1708936/pexels-photo-1708936.jpeg?auto=compress&cs=tinysrgb&w=400' },
  ];

  return (
    <section
      className="py-32 px-4 relative"
      style={{
        backgroundImage: `url('https://images.pexels.com/photos/2747449/pexels-photo-2747449.jpeg?auto=compress&cs=tinysrgb&w=1920')`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
      }}
    >
      <div className="absolute inset-0 bg-gradient-to-b from-black/80 to-black/90" />

      <div className="relative z-10 max-w-7xl mx-auto">
        <h2 className="text-6xl md:text-7xl font-black text-white text-center mb-16">
          LINE UP
        </h2>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-16">
          {artists.map((artist, index) => (
            <div key={index} className="group cursor-pointer">
              <div className="relative overflow-hidden rounded-lg aspect-[3/4] mb-4">
                <img
                  src={artist.image}
                  alt={artist.name}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-orange-500/80 via-teal-500/40 to-transparent" />
              </div>
              <h3 className="text-xl md:text-2xl font-black text-white text-center">
                {artist.name}
              </h3>
            </div>
          ))}
        </div>

        <div className="max-w-4xl mx-auto text-center">
          <p className="text-lg md:text-xl text-gray-200 leading-relaxed">
            Contamos con un line-up impresionante que combina artistas
            nacionales e internacionales de variados géneros musicales,
            garantizando diversión y entretenimiento para todos los públicos.
            La selección se realiza con el objetivo de ofrecer una
            experiencia musical diversa, moderna y memorable.
          </p>
        </div>
      </div>
    </section>
  );
}

export default Lineup;
