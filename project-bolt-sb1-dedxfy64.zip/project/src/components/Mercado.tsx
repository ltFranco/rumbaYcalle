function Mercado() {
  return (
    <section className="py-32 px-4 bg-black">
      <div className="max-w-7xl mx-auto">
        <h2 className="text-5xl md:text-6xl font-black text-white text-center mb-20">
          Análisis del Mercado: Escena Musical Dominicana
        </h2>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div className="bg-white rounded-3xl p-8 hover:scale-105 transition-transform duration-300">
            <h3 className="text-3xl font-black text-gray-900 mb-6">
              Demanda en<br />Eventos Musicales
            </h3>
            <p className="text-gray-700 leading-relaxed">
              La demanda de
              eventos musicales en la
              República Dominicana
              está en <span className="font-bold">constante
              crecimiento</span>, impulsada
              por un público joven
              que busca experiencias
              únicas y accesibles.
            </p>
          </div>

          <div className="bg-white rounded-3xl p-8 hover:scale-105 transition-transform duration-300">
            <h3 className="text-3xl font-black text-gray-900 mb-6">
              Mercados<br />Desatendidos
            </h3>
            <p className="text-gray-700 leading-relaxed">
              Existen <span className="font-bold">oportunidades
              significativas</span> en
              mercados
              desatendidos, donde
              los mini-festivales
              pueden atraer
              audiencias que
              actualmente no tienen
              acceso a este tipo de
              eventos.
            </p>
          </div>

          <div className="bg-white rounded-3xl p-8 hover:scale-105 transition-transform duration-300">
            <h3 className="text-3xl font-black text-gray-900 mb-6">
              Experiencias<br />Únicas
            </h3>
            <p className="text-gray-700 leading-relaxed">
              Los mini-festivales
              ofrecen <span className="font-bold">experiencias
              únicas</span> que combinan
              música, cultura y
              comunidad, creando un
              ambiente atractivo
              para los asistentes y
              promoviendo la
              diversidad artística.
            </p>
          </div>

          <div className="bg-white rounded-3xl p-8 hover:scale-105 transition-transform duration-300">
            <h3 className="text-3xl font-black text-gray-900 mb-6">
              Apoyo al Talento<br />Local
            </h3>
            <p className="text-gray-700 leading-relaxed">
              Al fomentar el talento
              local, Rumba & Calle
              Fest se alinea con las <span className="font-bold">necesidades del
              mercado</span>, estimulando
              el crecimiento de
              artistas emergentes y
              fortaleciendo la
              escena musical
              dominicana.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}

export default Mercado;
