function Hero() {
  return (
    <section className="relative h-screen overflow-hidden">
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage: `url('https://images.pexels.com/photos/1105666/pexels-photo-1105666.jpeg?auto=compress&cs=tinysrgb&w=1920')`,
        }}
      >
        <div className="absolute inset-0 bg-black/60" />
      </div>

      <div className="relative z-10 h-full flex flex-col items-center justify-center px-4">
        <div className="text-center mb-12">
          <h1 className="text-7xl md:text-9xl font-black text-white mb-4 tracking-tight">
            RUMBA<span className="text-white">&</span>
          </h1>
          <h1 className="text-7xl md:text-9xl font-black text-white mb-6 tracking-tight">
            CALLE
          </h1>
          <div className="inline-block bg-red-600 text-white text-4xl md:text-6xl font-black px-8 py-3 -rotate-2 transform">
            FEST
          </div>
        </div>

        <div className="mt-16 flex flex-wrap justify-center gap-8 items-center">
          <div className="text-center">
            <div className="w-48 h-32 bg-orange-600 rounded-lg flex items-center justify-center transform -rotate-3 shadow-xl">
              <span className="text-white text-3xl font-bold">BONAO</span>
            </div>
          </div>
          <div className="text-center">
            <div className="w-48 h-32 bg-teal-500 rounded-lg flex items-center justify-center transform rotate-2 shadow-xl">
              <span className="text-white text-3xl font-bold">LA VEGA</span>
            </div>
          </div>
          <div className="text-center">
            <div className="w-48 h-32 bg-white rounded-lg flex items-center justify-center transform -rotate-1 shadow-xl">
              <span className="text-gray-900 text-2xl font-bold">SANTIAGO</span>
            </div>
          </div>
          <div className="text-center">
            <div className="w-48 h-32 bg-purple-600 rounded-lg flex items-center justify-center transform rotate-3 shadow-xl">
              <span className="text-white text-3xl font-bold">BANÍ</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export default Hero;
